﻿<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title> 練習10資料庫作業2 </title>
</head>

<body>
    <h3>資料庫管理系統-修改</h3>
    <hr>
    <br>
    <form name="info" method="post" action="modifyResult.php">
            客戶代號: <input type="text" name="cust_no"><br>
            <br>
            <input type="submit" value="查詢">
            <br>
            <input type="reset" value="清除">
    </form>
    <form name="info" method="post" action="home.php">
            <input type="submit" value="回主畫面">
    </form>
<body>
<html>
