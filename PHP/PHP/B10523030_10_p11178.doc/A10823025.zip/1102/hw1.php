<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>hw1</title>
</head>
<body>
<center>
<h2>基本資料庫管理系統-查詢</h2>
<hr>
<form action="hw2.php" method="post">    		
編號: <input type="text" name="Access"> <br><br>
<button type="submit">查詢</button>
<button type="reset">清除</button>
</form>
<hr>

</body>
</html>