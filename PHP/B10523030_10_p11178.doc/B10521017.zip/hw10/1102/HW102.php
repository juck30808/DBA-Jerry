<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>HW102.php</title>
</head>
<body>
<h2 align='center'>基本資料管理系統-查詢</h2>
<hr>
<?php
// 是否是表單送回
if ( isset($_POST["no"]) ) {
// 取得SQL指令
	$db = dirname(__FILE__). "/testdb.accdb";
	$dsn = "DRIVER={Microsoft Access Driver (*.mdb, *.accdb)}; DBQ=$db;";
	$username = "";
	$password = "";
	$link = odbc_connect($dsn, $username, $password);
	$sql = "SELECT * FROM users WHERE [No] = ". $_POST["no"];
	$result = odbc_exec($link, $sql);
	$j = mb_convert_encoding(odbc_result($result, 1), "UTF-8", "BIG5");
	if ( $j != (int)$_POST["no"]) {
		echo "<p align='center'>編號: ".$_POST["no"]."</p><br/>";
		echo "<p align='center'><font align='center' color=\"RED\">！資料不存在！</font></p><br>";  
		echo "<form method='post' action='HW102.php' align='center'>";
		echo "<input type='submit' value='回查詢畫面'>";
		echo "</form>";
		echo "<hr>";
	} 
	else { 
		$field = array("編號:", "姓名:", "地址:", "電話:", "生日:", "Email:", "等級:");
		
		$total_rows = odbc_num_fields($result);
		echo "<table border=0 align='center'>";
		for ( $i = 0; $i < $total_rows-1; $i++ ){
			echo "<tr>";
			echo "<td><small>".$field[$i]."</small></td>";
			echo "<td><small>".mb_convert_encoding(odbc_result($result, $i+1), "UTF-8", "BIG5")."</small></td>";
			echo "</tr>";
		}
		echo "<tr>";
		echo "<td>";
		echo "<br>";
		echo "</td>";
		echo "</tr>";
		echo "<tr>";
		echo "<td></td>";
		echo "<td>";
		echo "<form method='post' action='HW102.php'>";
		echo "<input type='submit' value='回查詢畫面'>";
		echo "</form>";
		echo "</td>";
		echo "</tr>";
		echo "</table>";
		echo "<hr>";
	}
	odbc_free_result($result);
	odbc_close($link); // 關閉資料庫連接
	exit();
}

echo "<form method='post' action='HW102.php' align='center'>";
echo "編號：<input type='text' name='no'><br>";
echo "<br>";
echo "<table border=0 align='center'>";
echo "<tr>";
echo "<td>";
echo " ";
echo "</td>";
echo "<td>";
echo "<input type='submit' name='Query' value='查詢'>";
echo "</td>";
echo "<td>";
echo "<input type='reset' name='clear' value='清除'>";
echo "</td>";
echo "</tr>";
echo "</table>";
echo "</form>";
?>
<br>
<hr>
</body>
</html>