<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>HW101.php</title>
</head>
<body>
<?php
// 建立Access的資料庫連接
$db = dirname(__FILE__). "/testdb.accdb";
$dsn = "DRIVER={Microsoft Access Driver (*.mdb, *.accdb)}; DBQ=$db;";
$username = "";
$password = "";
$link = odbc_connect($dsn, $username, $password);

// 指定SQL查詢字串
$sql = "SELECT * FROM users";
// 送出查詢的SQL指令
$result = odbc_exec($link, $sql);

$total_fields = odbc_num_fields($result);

echo "<table border=1><tr>";
// 顯示欄位名稱
for ($i = 1; $i <= odbc_num_fields($result); $i++){
	echo "<td>" . odbc_field_name($result, $i) . "</td>";
}
echo "</tr>"; // 取得欄位數

$total_fields = odbc_num_fields($result);
// 顯示每一筆記錄{
while (odbc_fetch_row($result)) {
	echo "<tr>"; // 顯示每一筆記錄的欄位值
	for ( $i = 1; $i <= $total_fields; $i++ )
		echo "<td>" . mb_convert_encoding(odbc_result($result, $i), "UTF-8", "BIG5") . "</td>";
	echo "</tr>";
}
echo "</table>"; 
odbc_free_result($result); // 釋放佔用記憶體 
odbc_close($link);  // 關閉資料庫連接
?>
</body>
</html>