﻿<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title> 練習10資料庫作業2 </title>
</head>

<body>
    <hr>
    <h3>資料庫管理系統</h3>
    <hr>
        <form name="info" method="post" action="search.php">
                1.Search_<input type="submit" value="查詢" />
        </form><br>
        <form name="info" method="post" action="add.php">
                2.Add_<input type="submit" value="新增" />
        </form><br>
        <form name="info" method="post" action="modify.php">
                3.Modify_<input type="submit" value="修改" />
        </form><br>
        <form name="info" method="post" action="delete.php">
                4.Delete_<input type="submit" value="刪除" />
        </form><br>
    <hr>
</body>
<html>
