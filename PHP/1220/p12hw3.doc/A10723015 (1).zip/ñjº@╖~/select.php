﻿<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title> 練習10資料庫作業2 </title>
</head>

<body>
    <h3>資料庫管理系統-查詢</h3>
    <hr>
    <form name="info" method="post" action="selectResult.php">
            客戶代號: <input type="text" name="cust_no" size="15" /><br />
            <input type="submit" value="查詢" />
            <input type="reset" value="清除" />
    </form>
    <form name="info" method="post" action="home.php">
            <input type="submit" value="回主畫面" />
    </form>
<body>
<html>
