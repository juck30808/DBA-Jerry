﻿<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title> 練習10資料庫作業2 </title>
</head>

<body>
    <hr>
    <h3>資料庫管理系統</h3>
    <hr>
    <form name="info" method="post" action="select.php">
            1.<input type="submit" value="查詢" />
    </form>
    <form name="info" method="post" action="create.php">
            2.<input type="submit" value="新增" />
    </form>
    <form name="info" method="post" action="modify.php">
            3.<input type="submit" value="修改" />
    </form>
    <form name="info" method="post" action="delete.php">
            4.<input type="submit" value="刪除" />
    </form>

    <hr>
<body>
<html>
