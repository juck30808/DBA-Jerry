﻿﻿
<font color="red">非同步輸入資料</font><br>
非同步傳輸 輸入內容：使用者:<?php if (isset($_POST["no"])) echo $_POST["no"]; ?>
姓名: <?php if (isset($_POST["name"])) echo $_POST["name"]; ?><br>
