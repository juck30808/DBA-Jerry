﻿<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>學生成績管理系統</title>
</head>

<body>
    <h3>學生成績管理系統-查詢</h3>
    <hr>
    <form name="info" method="post" action="SearchResult.php">
            <br>
            學號: <input type="text" name="no1">
            <br>
            <br>
            <input type="submit" value="查詢">
            <br>
            <input type="reset" value="清除">
    </form>
    <form name="info" method="post" action="home.php">
            <input type="submit" value="回主畫面">
    </form>
<body>
<html>
