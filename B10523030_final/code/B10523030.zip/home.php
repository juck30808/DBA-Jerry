﻿<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title> 學生成績管理系統 </title>
</head>

<body>
    <hr>
    <h3>學生成績管理系統</h3>
    <hr>

        <form name="info" method="post" action="add.php">
                1.<input type="submit" value="新增" />
        </form><br>
        <form name="info" method="post" action="update.php">
                2.<input type="submit" value="修改" />
        </form><br>

        <form name="info" method="post" action="search.php">
                3.php ajax 資料庫 .<input type="submit" value="修改" />
        </form><br>


    <hr>
</body>
<html>
