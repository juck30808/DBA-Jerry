select *
from sc
where GRADE between 80 and 89
order by GRADE DESC;