select SNAME
from Student
where SEX = 'f';