select * 
from student;
