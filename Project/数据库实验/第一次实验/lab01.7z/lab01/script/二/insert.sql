insert into student values
(1001,'ZhangTia','m',10,20),
(1002,'LiLan','f',10,21),
(1003,'ChenMing','m',10,21),
(1004,'LiuQian','f',20,21),
(1005,'MaYang','m',20,22);

insert into course values
(1,'DataStructure',101,4),
(2,'DataBase',102,4),
(3,'DescreteMath',103,4),
(4,'CPrograming',101,2);

insert into sc values
(1001,1,80),(1001,2,85),(1001,3,78),
(1002,1,78),(1002,2,82),(1002,3,86),
(1003,1,92),(1003,3,90),
(1004,1,87),(1004,4,90),
(1005,1,85),(1005,4,92);

insert into teacher values
(101,'ZhangXin',10),(102,'LiShan',10),
(103,'ZhaoYing',10),(104,'LiuTian',20);

insert into dept values
(10,'ComputerScience'),(20,'Information');
