CREATE TABLE SC (
    SNO int,
    CNO int,
    GRADE int,
    primary key (SNO,CNO)
)