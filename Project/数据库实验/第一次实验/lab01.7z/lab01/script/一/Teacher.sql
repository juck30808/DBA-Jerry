CREATE TABLE Teacher (
    TNO int,
    TNAME char(8) not null,
    DEPTNO int,
    primary key(TNO)
)