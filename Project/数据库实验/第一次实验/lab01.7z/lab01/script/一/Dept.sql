Create table Dept (
    DEPTNO int primary key,
    DNAME char(20) not null
)